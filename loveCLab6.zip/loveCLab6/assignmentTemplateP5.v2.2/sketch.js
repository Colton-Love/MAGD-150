let positions = [];
let numCircles = 10;

function setup() {
  createCanvas(400, 400);

  for (let i = 0; i < numCircles; i++) {
    positions[i] = i * 40; // Evenly spaced x positions
  }

  console.log("Array length:", positions.length);
}

function draw() {
  background(220);

  for (let i = 0; i < positions.length; i++) {
    let y = 200 + sin(frameCount * 0.05 + i) * 50;

    ellipse(positions[i], y, 30, 30);
  }

  positions[0] = mouseX;
}
