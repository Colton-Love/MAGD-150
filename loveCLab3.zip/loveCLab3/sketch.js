let x;
let y;
let xSpeed;
let ySpeed;
let ballSize = 30;

function setup() {
  
  createCanvas(400, 400);

  x = random(width);
  y = random(height);

  xSpeed = random(2, 5);
  ySpeed = random(2, 5);
}

function draw() {
  background(220);

  fill(255, 0, 0); // red
  ellipse(x, y, ballSize);

  x += xSpeed;
  y += ySpeed;

  if (x > width + ballSize/2 || x < -ballSize/2 || 
      y > height + ballSize/2 || y < -ballSize/2) {
    
    x = random(width);
    y = random(height);

    xSpeed = random(2, 5) * (random() < 0.5 ? 1 : -1);
    ySpeed = random(2, 5) * (random() < 0.5 ? 1 : -1);
  }
}
