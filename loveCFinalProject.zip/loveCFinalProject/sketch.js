let colorButton;
let graySlider;
let timeDial;

let grayValue = 50;
let stars = [];
let starBaseColors = [];
let planets = [];
let timeAngle = 0;

function setup() {
  createCanvas(800, 500);

  for (let i = 0; i < 150; i++) {
    stars.push({
      x: random(width),
      y: random(height),
      size: random(1, 3)
    });
    starBaseColors.push(color(random(255), random(255), random(255)));
  }

  for (let i = 0; i < 6; i++) {
    planets.push({
      orbitRadius: random(150, 350),
      orbitYOffset: random(height * 0.35, height * 0.65),
      baseSize: random(40, 90),
      phase: random(TWO_PI),
      baseColor: color(random(255), random(255), random(255))
    });
  }

  colorButton = new Button("box", width - 190, 30);
  colorButton.width = 170;
  colorButton.height = 40;
  colorButton.onPressEnd = () => {
    for (let i = 0; i < starBaseColors.length; i++) {
      starBaseColors[i] = color(random(255), random(255), random(255));
    }
    for (let p of planets) {
      p.baseColor = color(random(255), random(255), random(255));
    }
  };

  graySlider = new Slider("box", false, 60, 80);
  graySlider.Slength = 300;
  graySlider.onValueChange = () => {
    grayValue = map(graySlider.value, 0, graySlider.Slength, 0, 255);
  };

  timeDial = new Dial(false, 100, height - 80);
  timeDial.radius = 60;
  timeDial.onValueChange = () => {
    timeAngle = timeDial.value;
  };
}

function draw() {
  background(grayValue);

  let t = (timeAngle % 360) / 360;
  let gCol = color(grayValue);
  let sunX = width / 2;
  let sunY = height / 2;

  noStroke();
  for (let i = 0; i < stars.length; i++) {
    let s = stars[i];
    let offsetX = map(t, 0, 1, -width, width);
    let x = (s.x + offsetX + width * 2) % width;
    let baseCol = starBaseColors[i];
    let starCol = lerpColor(gCol, baseCol, 0.7);
    fill(starCol);
    circle(x, s.y, s.size);
  }

  let planetRender = [];
  for (let p of planets) {
    let angle = t * TWO_PI + p.phase;
    let px = sunX + cos(angle) * p.orbitRadius;
    let py = p.orbitYOffset + sin(angle) * (p.orbitRadius * 0.3);
    let farX = width;
    let farY = 0;
    let d = dist(px, py, farX, farY);
    let maxD = dist(0, 0, width, height);
    let scale = map(d, 0, maxD, 0.3, 1.2);
    let planetCol = lerpColor(gCol, p.baseColor, 0.7);
    planetRender.push({
      x: px,
      y: py,
      size: p.baseSize * scale,
      col: planetCol
    });
  }

  for (let pr of planetRender) {
    if (pr.y < sunY) {
      fill(pr.col);
      circle(pr.x, pr.y, pr.size);
    }
  }

  fill(255, 230, 120);
  circle(sunX, sunY, 180);

  for (let pr of planetRender) {
    if (pr.y >= sunY) {
      fill(pr.col);
      circle(pr.x, pr.y, pr.size);
    }
  }

  fill(0);
  textSize(16);
  textAlign(LEFT, CENTER);
  text("Grayscale", graySlider.x + graySlider.Slength + 20, graySlider.y);
  text("Time Dial", timeDial.x + 100, timeDial.y);
  text("Randomize Colors", colorButton.x + 10, colorButton.y + 25);

  colorButton.draw();
  graySlider.draw();
  timeDial.draw();
}
